# pps-diagnosis-import

Node JS Installation - Version 10 or Greater
Browser - Chrome, Firefox, Safari, Edge


Run 'npm install' to install application dependencies

